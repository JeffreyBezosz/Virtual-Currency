<?php

return [
    'host' => 'sqlXXX.infinityfree.com',
    'database' => 'if0_XXXXXXX_virtual_currency',
    'username' => 'if0_XXXXXXX',
    'password' => 'VUL_HIER_JE_DATABASE_WACHTWOORD_IN',
];
